package com.ensat.services.impl;

import com.ensat.entities.operations.AccountInfo;
import com.ensat.repositories.AccountInfoRepository;
import com.ensat.services.AccountInfoService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultAccountInfoService implements AccountInfoService {

    private AccountInfoRepository accountInfoRepository;

    @Override
    public AccountInfo getAccountInfo(int id) {

        return accountInfoRepository.findById(id).orElse(null);
    }
}
