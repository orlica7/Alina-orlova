package com.ensat.controllers;

import com.ensat.AccountBalanceService;
import com.ensat.entities.operations.Contract;
import com.ensat.services.ActionService;
import com.ensat.services.ClientService;
import com.ensat.services.ContractService;
import lombok.Setter;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@Setter(onMethod = @__(@Autowired))
public class DepositController {

    private ContractService contractService;
    private AccountBalanceService accountBalanceService;
    private ActionService actionService;
    private ClientService clientService;

    @Autowired
    private LocalDate localDate;

    @RequestMapping(value = "/deposits", method = GET)
    public String list(Model model) {

        model.addAttribute("contracts", contractService.listAllDepositContracts());
        return "deposits";
    }

    @RequestMapping("deposit/{id}")
    public String showCredit(@PathVariable Integer id, Model model) {

        model.addAttribute("contract", contractService.getContractInfo(id));
        return "depositShow";
    }
    @RequestMapping("deposit/delete/{id}")
    public String delete(@PathVariable Integer id) {

        contractService.deleteContract(id);
        return "redirect:/deposits";
    }
    @RequestMapping("deposit/new")
    public String newCredit(Model model) {

        model.addAttribute("contract", new Contract());
        addModelAttributes(model);
        return "depositForm";
    }

    @RequestMapping(value = "deposit", method = POST)
    public String saveCredit(@Valid Contract contract, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("contract", contract);
            addModelAttributes(model);
            return "depositForm";
        } else {

            contract.setCreatedDate(localDate);
            contract.setLastBalanced(new LocalDate(localDate));
            contract.setStatus(true);
            contractService.saveContract(contract);
            accountBalanceService.addAccounts(contract);
            return "redirect:/deposit/" + contract.getId();
        }
    }

    private void addModelAttributes(Model model) {

        model.addAttribute("deposits", actionService.listAllDeposits());
        model.addAttribute("clients", clientService.listAllClients());
    }
}
