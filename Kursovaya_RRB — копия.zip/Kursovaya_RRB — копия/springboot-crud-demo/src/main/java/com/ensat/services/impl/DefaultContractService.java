package com.ensat.services.impl;

import com.ensat.entities.operations.Contract;
import com.ensat.repositories.ContractRepository;
import com.ensat.services.ContractService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultContractService implements ContractService {

    private ContractRepository contractRepository;

    @Override
    public Iterable<Contract> listAllDepositContracts() {

        return findByKind("Депозит");
    }

    @Override
    public Iterable<Contract> listAllCreditContracts() {

        return findByKind("Кредит");
    }

    @Override
    public Contract getContractInfo(int id) {

        return contractRepository.findById(id).orElse(null);
    }
    @Override
    public Contract getContractById(Integer id) {

        return contractRepository.findById(id).orElse(null);
    }
    @Override
    public void deleteContract(Integer id) {

        contractRepository.deleteById(id);
    }
    @Override
    public void saveContract(Contract contract) {

        contractRepository.save(contract);
    }

    @Override
    public Iterable<Contract> listAllContracts() {

        return contractRepository.findAll();
    }

    private List<Contract> findByKind(String kind) {

        List<Contract> result = new ArrayList<>();

        contractRepository.findAll().forEach((contract) -> {

            if (contract.getAction().getKind().equals(kind)) {

                result.add(contract);
            }
        });
        return result;
    }
}
