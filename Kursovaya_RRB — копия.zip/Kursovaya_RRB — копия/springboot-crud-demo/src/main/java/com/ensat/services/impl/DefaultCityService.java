package com.ensat.services.impl;

import com.ensat.entities.clients.City;
import com.ensat.repositories.CityRepository;
import com.ensat.services.CityService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultCityService implements CityService {

    private CityRepository cityRepository;

    @Override
    public Iterable<City> listAllCities() {

        return cityRepository.findAll();
    }
}
