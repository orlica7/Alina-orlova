package com.ensat.controllers;

import com.ensat.AccountBalanceService;
import com.ensat.entities.operations.Contract;
import com.ensat.services.ActionService;
import com.ensat.services.ClientService;
import com.ensat.services.ContractService;
import lombok.Setter;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@Setter(onMethod = @__(@Autowired))
public class CreditController {

    private ContractService contractService;
    private AccountBalanceService accountBalanceService;
    private ActionService actionService;
    private ClientService clientService;

    @Autowired
    public LocalDate localDate;

    @RequestMapping(value = "/credits",  method = GET)
    public String list(Model model) {

        model.addAttribute("contracts", contractService.listAllCreditContracts());
        return "credits";
    }

    @RequestMapping("credit/{id}")
    public String showClient(@PathVariable Integer id, Model model) {

        model.addAttribute("contract", contractService.getContractById(id));
        addModelAttributes(model);
        return "creditShow";
    }

    @RequestMapping("credit/new")
    public String newCredit(Model model) {

        model.addAttribute("contract", new Contract());
        addModelAttributes(model);
        return "creditForm";
    }
    @RequestMapping("credit/delete/{id}")
    public String delete(@PathVariable Integer id) {

        contractService.deleteContract(id);
        return "redirect:/credits";
    }


    @RequestMapping(value = "credit", method = POST)
    public String saveCredit(@Valid Contract contract, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("contract", contract);
            addModelAttributes(model);
            return "creditForm";
        } else {

            contract.setCreatedDate(localDate);
            contract.setLastBalanced(localDate);
            contract.setStatus(true);
            contractService.saveContract(contract);
            accountBalanceService.addAccounts(contract);
            return "redirect:/credit/" + contract.getId();
        }
    }

    private void addModelAttributes(Model model) {

        model.addAttribute("credits", actionService.listAllCredits());
        model.addAttribute("clients", clientService.listAllClients());
    }
}

