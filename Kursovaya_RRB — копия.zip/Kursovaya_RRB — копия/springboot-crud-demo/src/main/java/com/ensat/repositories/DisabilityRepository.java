package com.ensat.repositories;

import com.ensat.entities.clients.Disability;
import org.springframework.data.repository.CrudRepository;

public interface DisabilityRepository extends CrudRepository<Disability, Integer> {

}
