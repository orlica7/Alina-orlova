package com.ensat.controllers;

import com.ensat.AccountBalanceService;
import com.ensat.services.AccountService;
import com.ensat.services.ContractService;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Controller
@Setter(onMethod = @__(@Autowired))
public class BankServiceController {

    private AccountService accountService;
    private AccountBalanceService accountBalanceService;
    private ContractService contractService;

    @RequestMapping(value = "/closeBankDay", method = GET)
    String closeBankDay(Model model) {

        contractService.listAllContracts().forEach((contract) -> accountBalanceService.closeBankDay(contract));
        model.addAttribute("accounts", accountService.listAllAccounts());
        return "accounts";
    }
}
