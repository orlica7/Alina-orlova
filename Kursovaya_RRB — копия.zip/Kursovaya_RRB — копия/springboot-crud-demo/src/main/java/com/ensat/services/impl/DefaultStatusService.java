package com.ensat.services.impl;

import com.ensat.entities.clients.FamilyStatus;
import com.ensat.repositories.FamilyStatusRepository;
import com.ensat.services.StatusService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultStatusService implements StatusService {

    private FamilyStatusRepository familyStatusRepository;

    @Override
    public Iterable<FamilyStatus> listAllStatus() {

        return familyStatusRepository.findAll();
    }
}
