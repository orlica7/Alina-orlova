package com.ensat.services;

import com.ensat.entities.clients.Disability;

public interface DisabilityService {

    Iterable<Disability> listAllDisabilities();
}
