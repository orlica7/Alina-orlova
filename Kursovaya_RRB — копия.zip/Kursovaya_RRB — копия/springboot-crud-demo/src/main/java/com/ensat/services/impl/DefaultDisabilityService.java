package com.ensat.services.impl;

import com.ensat.entities.clients.Disability;
import com.ensat.repositories.DisabilityRepository;
import com.ensat.services.DisabilityService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultDisabilityService implements DisabilityService {

    private DisabilityRepository disabilityRepository;

    @Override
    public Iterable<Disability> listAllDisabilities() {

        return disabilityRepository.findAll();
    }
}
