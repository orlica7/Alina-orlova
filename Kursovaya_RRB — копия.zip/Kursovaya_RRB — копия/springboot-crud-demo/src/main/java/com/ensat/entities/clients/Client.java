package com.ensat.entities.clients;

import com.ensat.entities.operations.Contract;
import lombok.Getter;
import lombok.Setter;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "Clients")
public class Client {

    private static final String NOT_BLANK = "Данное поле не может быть пустым!";
    private static final String INVALID_DATA = "Проверьте корректность введенных данных!";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Integer id;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[А-ЯЁа-яёA-Za-z- ]*$", message = INVALID_DATA)
    @Column(name = "LastName", nullable = false)
    private String lastName;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[А-ЯЁа-яёA-Za-z- ]*$", message = INVALID_DATA)
    @Column(name = "FirstName", nullable = false)
    private String firstName;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[А-ЯЁа-яёA-Za-z ]*$", message = INVALID_DATA)
    @Column(name = "PatronymicName", nullable = false)
    private String patronymicName;

    @NotBlank(message = NOT_BLANK)
    @Column(name = "BirthDate", nullable = false)
    private String birthDate;

    @Column(nullable = false, name = "Sex")
    private boolean sex;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[A-Z]{2}$", message = INVALID_DATA)
    @Column(name = "PassportSeries", nullable = false)
    private String passSeries;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[0-9]{7}$", message = INVALID_DATA)
    @Column(name = "PassportNumber", nullable = false)
    private String passNumber;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[А-ЯЁа-яёA-Za-z- ]*$", message = INVALID_DATA)
    @Column(name = "PassportAuthority", nullable = false)
    private String passAuthority;

    @NotBlank(message = NOT_BLANK)
    @Column(name = "PassportIssueDate", nullable = false)
    private String passIssueDate;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[1-6][0-9]{6}[ABCKEMH][0-9]{3}[A-Z]{2}[0-9]$", message = INVALID_DATA)
    @Column(name = "PassportIdentificationNumber", unique = true, nullable = false)
    private String passIdentificationNumber;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[А-ЯЁа-яёA-Za-z-,. ]*$", message = INVALID_DATA)
    @Column(name = "BirthPlace", nullable = false)
    private String birthPlace;

    @NotBlank(message = NOT_BLANK)
    @Pattern(regexp = "^[А-ЯЁа-яёA-Za-z- 1-9,./]*$", message = INVALID_DATA)
    @Column(name = "CurrentAddress", nullable = false)
    private String currentAddress;

    @NotNull
    @Column(name = "RetirementStatus", columnDefinition = "boolean default false")
    private boolean isRetired;

    @Nullable
    @Pattern(regexp = "^(?:8-[0-9]{3,5}-[0-9]{5,7})?$", message = INVALID_DATA)
    @Column(name = "HomePhone")
    private String homePhone;

    @Pattern(regexp = "^(?:[+]375-[0-9]{2}-[0-9]{3}-[0-9]{2}-[0-9]{2})?$", message = INVALID_DATA)
    @Column(name = "MobilePhone")
    private String mobilePhone;

    @Column(name = "MonthlyIncome")
    private Double monthlyIncome;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "CurrentCities",
        joinColumns = @JoinColumn(name = "client_id"),
        inverseJoinColumns = @JoinColumn(name = "city_id"))
    @Size(min = 1, max = 5, message = "Выберите город!")
    Set<City> currentCities = new HashSet<>();

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "ResidenceCities",
        joinColumns = @JoinColumn(name = "client_id"),
        inverseJoinColumns = @JoinColumn(name = "city_id"))
    @Size(min = 1, max = 5, message = "Выберите город!")
    Set<City> residenceCities = new HashSet<>();

    @ManyToOne(targetEntity = FamilyStatus.class, optional = false)
    @JoinColumn(name = "FamilyStatus")
    private FamilyStatus familyStatus;

    @ManyToOne(targetEntity = Disability.class, optional = false)
    @JoinColumn(name = "Disability")
    private Disability disability;

    @ManyToOne(targetEntity = Nationality.class, optional = false)
    @JoinColumn(name = "Nationality")
    private Nationality nationality;

    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL)
    private Set<Contract> contracts = new HashSet<>();

    public String getCities(Set<City> cities) {

        StringBuilder result = new StringBuilder();
        cities.forEach((city) -> result.append(city.getCity()).append(", "));
        result.deleteCharAt(result.length() - 2);
        return result.toString();
    }

    public String getRetirementStatus() {

        return isRetired ? "да" : "нет";
    }

    public String sexToString() {

        return sex ? "женский" : "мужской";
    }

    public String getName() {

        return lastName + " " + firstName + " " + patronymicName;
    }
}
