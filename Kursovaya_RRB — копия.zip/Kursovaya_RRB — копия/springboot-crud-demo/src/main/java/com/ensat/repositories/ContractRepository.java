package com.ensat.repositories;

import com.ensat.entities.operations.Contract;
import org.springframework.data.repository.CrudRepository;

public interface ContractRepository extends CrudRepository<Contract, Integer> {

}
