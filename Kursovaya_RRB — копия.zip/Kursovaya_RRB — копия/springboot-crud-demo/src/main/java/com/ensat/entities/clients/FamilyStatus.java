package com.ensat.entities.clients;

import lombok.Getter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity
@Table(name = "Status")
public class FamilyStatus {

    @Id
    @Column(name = "ID")
    private int id;
    @Column(name = "Status")
    private String status;

    @OneToMany(fetch=FetchType.LAZY, mappedBy="familyStatus")
    private Set<Client> clients = new HashSet<>();
}
