package com.ensat.services;

import com.ensat.entities.clients.FamilyStatus;

public interface StatusService {

    Iterable<FamilyStatus> listAllStatus();
}
