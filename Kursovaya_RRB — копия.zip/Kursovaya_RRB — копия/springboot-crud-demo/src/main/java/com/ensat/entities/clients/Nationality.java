package com.ensat.entities.clients;

import lombok.Getter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity
@Table(name = "Nationalities")
public class Nationality {

    @Id
    @Column(name = "ID")
    private int id;
    @Column(name = "Nationality")
    private String nationality;

    @OneToMany(fetch=FetchType.LAZY, mappedBy="nationality")
    private Set<Client> clients = new HashSet<>();
}
