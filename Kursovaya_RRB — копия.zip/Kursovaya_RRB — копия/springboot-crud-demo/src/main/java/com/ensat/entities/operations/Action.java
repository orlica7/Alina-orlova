package com.ensat.entities.operations;

import lombok.Getter;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity
@Table(name = "Actions")
public class Action {

    @Id
    @Column(name = "ID")
    private int id;

    @Column(name = "Kind")
    private String kind;

    @NotBlank
    @Column(name = "Name")
    private String name;

    @NotBlank
    @Column(name = "Rate")
    private double Rate;

    @OneToMany(mappedBy = "action")
    private Set<Contract> contracts = new HashSet<>();
}
