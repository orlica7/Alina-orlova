package com.ensat.services.impl;

import com.ensat.entities.clients.Client;
import com.ensat.repositories.ClientRepository;
import com.ensat.services.ClientService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultClientService implements ClientService {

    private ClientRepository clientRepository;

    @Override
    public Iterable<Client> listAllClients() {

        return clientRepository.findAll();
    }

    @Override
    public Client getClientById(Integer id) {

        return clientRepository.findById(id).orElse(null);
    }

    @Override
    public Client saveClient(Client client) {

        return clientRepository.save(client);
    }

    @Override
    public void deleteClient(Integer id) {

        clientRepository.deleteById(id);
    }
}
