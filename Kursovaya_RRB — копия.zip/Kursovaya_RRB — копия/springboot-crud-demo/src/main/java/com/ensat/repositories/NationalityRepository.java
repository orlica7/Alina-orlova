package com.ensat.repositories;

import com.ensat.entities.clients.Nationality;
import org.springframework.data.repository.CrudRepository;

public interface NationalityRepository extends CrudRepository<Nationality, Integer> {

}
