package com.ensat.services;

import com.ensat.entities.operations.Action;

public interface ActionService {

    Iterable<Action> listAllDeposits();
    Iterable<Action> listAllCredits();

}
