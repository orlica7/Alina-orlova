package com.ensat.repositories;

import com.ensat.entities.clients.FamilyStatus;
import org.springframework.data.repository.CrudRepository;

public interface FamilyStatusRepository extends CrudRepository<FamilyStatus, Integer> {

}
