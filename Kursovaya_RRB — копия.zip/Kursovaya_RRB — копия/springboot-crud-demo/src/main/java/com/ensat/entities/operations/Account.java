package com.ensat.entities.operations;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Getter
@Entity
@Setter
@Table(name = "Accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private int id;

    @NotNull
    @Column(name = "Number", unique = true)
    private long number;

    @Column(name = "Balance")
    private Double balance;

    @ManyToOne(targetEntity = Contract.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Contract")
    private Contract contract;

    @ManyToOne(targetEntity = AccountInfo.class)
    @JoinColumn(name = "AccountInfo")
    private AccountInfo accountInfo;
}
