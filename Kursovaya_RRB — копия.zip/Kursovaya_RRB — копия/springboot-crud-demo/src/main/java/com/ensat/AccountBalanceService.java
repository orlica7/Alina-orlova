package com.ensat;

import com.ensat.entities.operations.Account;
import com.ensat.entities.operations.Contract;
import com.ensat.services.AccountInfoService;
import com.ensat.services.AccountService;
import lombok.AllArgsConstructor;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

@AllArgsConstructor(onConstructor = @__(@Autowired))
@Service
public class AccountBalanceService {

    private AccountService accountService;
    private AccountInfoService accountInfoService;

    public void addAccounts(Contract contract) {

        Account bankAccount = accountService.getBankAccount();
        Double accountBalance = bankAccount.getBalance();

        switch (contract.getAction().getKind()) {

            case "Депозит": {

                bankAccount.setBalance(accountBalance + contract.getSum());
                Account currentAccount = generateAccount(contract, 1, 3014, false, contract.getSum());
                Account percentAccount = generateAccount(contract, 1, 3014, true, 0.0);
                accountService.saveAccount(currentAccount);
                accountService.saveAccount(percentAccount);
            }
            break;

            case "Кредит": {

                bankAccount.setBalance(accountBalance - contract.getSum());
                Account currentAccount = generateAccount(contract, 2, 2400, false, -contract.getSum());
                Account percentAccount = generateAccount(contract, 2, 2400, true, 0.0);
                accountService.saveAccount(currentAccount);
                accountService.saveAccount(percentAccount);
            }
        }
    }

    public void closeBankDay(Contract contract) {

        Account bankAccount = accountService.getBankAccount();

        Set<Account> accounts = contract.getAccounts();
        Account currentAccount = null, percentAccount = null;
        for (Account account : accounts) { //распрр-е по тек. и % счету
            if (String.valueOf(account.getNumber()).charAt(4) == '1') {
                currentAccount = account;
            } else {
                percentAccount = account;
            }
        }

        LocalDate currentDate = new LocalDate();
        LocalDate createdDate = contract.getCreatedDate();
        LocalDate lastBalanced = contract.getLastBalanced();

        double dailyRate = (contract.getAction().getRate() / 36500); //ставка 1 дня и проценты
        boolean isClosed = createdDate.plusMonths(contract.getTerm()).isBefore(currentDate);
        int daysPassedSinceLastBalance;
        if (!isClosed) {
            daysPassedSinceLastBalance = Days.daysBetween(lastBalanced, currentDate).getDays();
        } else {
            daysPassedSinceLastBalance = Days.daysBetween(lastBalanced, createdDate.plusMonths(contract.getTerm())).getDays();
        }
        Double percent = contract.getSum() * daysPassedSinceLastBalance * dailyRate;

        switch (contract.getAction().getKind()) {

            case "Депозит": {

                if (contract.getStatus()) {

                    percentAccount.setBalance(percentAccount.getBalance() + percent);
                    bankAccount.setBalance(bankAccount.getBalance() - percent);

                    if (createdDate.plusMonths(contract.getTerm()).isBefore(currentDate)) {

                        currentAccount.setBalance(currentAccount.getBalance() + percentAccount.getBalance());

                        bankAccount.setBalance(bankAccount.getBalance() - contract.getSum());
                        percentAccount.setBalance(0.0);
                        contract.setStatus(false);
                    }
                }
            }
            break;
            case "Кредит": {

                if (contract.getStatus()) {

                    percentAccount.setBalance(percentAccount.getBalance() - percent);
                    bankAccount.setBalance(bankAccount.getBalance() + percent);

                    if (createdDate.plusMonths(contract.getTerm()).isBefore(currentDate)) {

                        currentAccount.setBalance(currentAccount.getBalance() - percentAccount.getBalance());

                        bankAccount.setBalance(bankAccount.getBalance() + contract.getSum());
                        percentAccount.setBalance(0.0);
                        contract.setStatus(false);
                    }
                }
            }
            break;
        }

        contract.setLastBalanced(currentDate);
        accountService.saveAccount(currentAccount);
        accountService.saveAccount(percentAccount);
    }

    private long generateAccountNumber(int code, boolean isPercentAccount) {

        StringBuilder result = new StringBuilder().append(code);
        if (isPercentAccount) {
            result.append(2);
        } else {
            result.append(1);
        }
        String timestamp = String.valueOf(System.currentTimeMillis());
        result.append(timestamp.substring(timestamp.length() - 8));

        return Long.parseLong(result.toString());
    }

    private Account generateAccount(Contract contract, int accountInfo, int code, boolean isPercentAccount, Double
            balance) {

        Account account = new Account();
        account.setAccountInfo(accountInfoService.getAccountInfo(accountInfo));
        account.setContract(contract);
        account.setNumber(generateAccountNumber(code, isPercentAccount));
        account.setBalance(balance);
        return account;
    }
}
