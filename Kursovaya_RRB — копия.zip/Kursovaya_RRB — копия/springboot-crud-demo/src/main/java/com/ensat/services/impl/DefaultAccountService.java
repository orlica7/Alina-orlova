package com.ensat.services.impl;

import com.ensat.entities.operations.Account;
import com.ensat.repositories.AccountRepository;
import com.ensat.services.AccountService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultAccountService implements AccountService {

    private AccountRepository accountRepository;

    @Override
    public Iterable<Account> listAllAccounts() {

        return accountRepository.findAll();
    }

    @Override
    public void saveAccount(Account account) {

        accountRepository.save(account);
    }

    @Override
    public Account getBankAccount() {

        return accountRepository.findById(1).orElse(null);
    }
}
