package com.ensat.services;

import com.ensat.entities.operations.Contract;

public interface ContractService {

    Iterable<Contract> listAllDepositContracts();

    Iterable<Contract> listAllCreditContracts();

    Contract getContractInfo(int id);
    Contract getContractById(Integer id);
    void deleteContract(Integer id);
    void saveContract(Contract contract);

    Iterable<Contract> listAllContracts();
}
