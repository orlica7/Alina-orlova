package com.ensat.entities.clients;

import lombok.Getter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity
@Table(name = "Disabilities")
public class Disability {

    @Id
    @Column(name = "ID")
    private int id;
    @Column(name = "Disability")
    private String disability;

    @OneToMany(fetch=FetchType.LAZY, mappedBy="disability")
    private Set<Client> clients = new HashSet<>();
}
