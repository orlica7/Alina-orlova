package com.ensat.services.impl;

import com.ensat.entities.clients.Nationality;
import com.ensat.repositories.NationalityRepository;
import com.ensat.services.NationalityService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultNationalityService implements NationalityService {

    private NationalityRepository nationalityRepository;

    @Override
    public Iterable<Nationality> listAllNationalities() {

        return nationalityRepository.findAll();
    }
}
