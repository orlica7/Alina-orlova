package com.ensat.services;

import com.ensat.entities.operations.Account;

public interface AccountService {

    Iterable<Account> listAllAccounts();

    void saveAccount(Account account);

    Account getBankAccount();
}
