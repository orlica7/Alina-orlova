package com.ensat.entities.operations;

import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Setter
public class AccountInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private int id;

    @Column(name = "Code")
    private int code;

    @Column(name = "Details")
    private String details;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "accountInfo")
    private Set<Account> accounts = new HashSet<>();
}
