package com.ensat.entities.operations;

import com.ensat.entities.clients.Client;
import lombok.Getter;
import lombok.Setter;
import org.joda.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "Contracts")
public class Contract {

    private static final String NOT_BLANK = "Поле не может быть пустым.";

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @NotNull(message = NOT_BLANK)
    @Column(name = "Sum")
    private Double sum;

    @NotNull(message = NOT_BLANK)
    @Column(name = "Term")
    private Integer term;

    @Column(name = "CreatedDate")
    private LocalDate createdDate;

    @Column(name = "Status", columnDefinition = "boolean default true")
    private Boolean status;

    @Column(name = "LastBalanceDate")
    private LocalDate lastBalanced;
    @ManyToOne(targetEntity = Action.class, optional = false)
    @JoinColumn(name = "Action")
    private Action action;

    @ManyToOne(targetEntity = Client.class, optional = false)
    @JoinColumn(name = "Client")
    private Client client;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "contract", cascade = CascadeType.ALL)
    private Set<Account> accounts = new HashSet<>();

    public String getStatusString() {

        return status ? "активный" : "закрыт";
    }
}
