package com.ensat.controllers;

import com.ensat.entities.clients.Client;
import com.ensat.services.*;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@Setter(onMethod = @__(@Autowired))
public class ClientController {

    private ClientService clientService;
    private CityService cityService;
    private StatusService statusService;
    private NationalityService nationalityService;
    private DisabilityService disabilityService;

    @RequestMapping(value = "/clients", method = GET)
    public String list(Model model) {

        model.addAttribute("clients", clientService.listAllClients());
        return "clients";
    }

    @RequestMapping("client/{id}")
    public String showClient(@PathVariable Integer id, Model model) {

        model.addAttribute("client", clientService.getClientById(id));
        addModelAttributes(model);
        return "clientShow";
    }

    @RequestMapping("client/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {

        model.addAttribute("client", clientService.getClientById(id));
        addModelAttributes(model);
        return "clientForm";
    }

    @RequestMapping("client/new")
    public String newClient(Model model) {

        model.addAttribute("client", new Client());
        addModelAttributes(model);
        return "clientForm";
    }

    @RequestMapping(value = "client", method = POST)
    public String saveClient(@Valid Client client, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("client", client);
            addModelAttributes(model);
            return "clientForm";
        } else {
            clientService.saveClient(client);
            return "redirect:/client/" + client.getId();
        }
    }

    @RequestMapping("client/delete/{id}")
    public String delete(@PathVariable Integer id) {

        clientService.deleteClient(id);
        return "redirect:/clients";
    }

    private void addModelAttributes(Model model) {

        model.addAttribute("cities", cityService.listAllCities());
        model.addAttribute("status", statusService.listAllStatus());
        model.addAttribute("disabilities", disabilityService.listAllDisabilities());
        model.addAttribute("nationalities", nationalityService.listAllNationalities());
    }
}
