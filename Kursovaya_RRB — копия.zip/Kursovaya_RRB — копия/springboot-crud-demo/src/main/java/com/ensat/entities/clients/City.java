package com.ensat.entities.clients;

import lombok.Getter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity
@Table(name = "Cities")
public class City {

    @Id
    @Column(name = "ID")
    private int id;
    @Column(name = "City")
    private String city;

    @ManyToMany
    @JoinTable(name = "CurrentCities",
        joinColumns = @JoinColumn(name = "city_id"),
        inverseJoinColumns = @JoinColumn(name = "client_id"))
    private Set<Client> clients = new HashSet<>();

    @ManyToMany
    @JoinTable(name = "ResidenceCities",
        joinColumns = @JoinColumn(name = "city_id"),
        inverseJoinColumns = @JoinColumn(name = "client_id"))
    private Set<Client> residents = new HashSet<>();
}