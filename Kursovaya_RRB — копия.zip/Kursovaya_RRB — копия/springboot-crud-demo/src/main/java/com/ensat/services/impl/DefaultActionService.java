package com.ensat.services.impl;

import com.ensat.entities.operations.Action;
import com.ensat.repositories.ActionRepository;
import com.ensat.services.ActionService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Setter(onMethod = @__(@Autowired))
@Service
public class DefaultActionService implements ActionService {

    private ActionRepository actionRepository;

    @Override
    public Iterable<Action> listAllDeposits() {

        return findByKind("Депозит");
    }

    @Override
    public Iterable<Action> listAllCredits() {

        return findByKind("Кредит");
    }

    private List<Action> findByKind(String kind) {

        List<Action> result = new ArrayList<>();

        actionRepository.findAll().forEach((action) -> {

            if (action.getKind().equals(kind)) {

                result.add(action);
            }
        });

        return result;
    }
}
