package com.ensat.services;

import com.ensat.entities.clients.Nationality;

public interface NationalityService {

    Iterable<Nationality> listAllNationalities();
}
