package com.ensat.repositories;

import com.ensat.entities.operations.AccountInfo;
import org.springframework.data.repository.CrudRepository;

public interface AccountInfoRepository extends CrudRepository<AccountInfo, Integer> {

}
