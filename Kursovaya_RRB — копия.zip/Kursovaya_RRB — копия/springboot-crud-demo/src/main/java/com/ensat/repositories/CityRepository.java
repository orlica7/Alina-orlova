package com.ensat.repositories;

import com.ensat.entities.clients.City;
import org.springframework.data.repository.CrudRepository;

public interface CityRepository extends CrudRepository<City, Integer> {

}
