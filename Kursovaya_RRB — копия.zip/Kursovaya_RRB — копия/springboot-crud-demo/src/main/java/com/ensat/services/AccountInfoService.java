package com.ensat.services;

import com.ensat.entities.operations.AccountInfo;

public interface AccountInfoService {

    AccountInfo getAccountInfo(int id);
}
