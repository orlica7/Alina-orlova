package com.ensat.repositories;

import com.ensat.entities.operations.Action;
import org.springframework.data.repository.CrudRepository;

public interface ActionRepository extends CrudRepository<Action, Integer> {

}
